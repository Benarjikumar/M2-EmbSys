# **COMPONENT DIAGRAM**

![Block Diagram](https://user-images.githubusercontent.com/94182282/142772868-545aa00e-d2de-49a2-b063-cc52ab0aaec8.png)
# **CLASS DIAGRAM**

![Class diagram](https://user-images.githubusercontent.com/94182282/143177068-17911233-c9f1-4586-b379-bf7bf94bec89.png)
