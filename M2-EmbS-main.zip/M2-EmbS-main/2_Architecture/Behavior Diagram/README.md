# **UML DIAGRAM**

![Behavioural Diagram](https://user-images.githubusercontent.com/94182282/142769917-e193c9b0-9371-4b7f-a232-46cf64e173a1.png)

# **FLOW CHART**

![Flowchart](https://user-images.githubusercontent.com/94182282/142772416-4f56855a-2d65-4936-af49-1eaec09a8bb4.png)
